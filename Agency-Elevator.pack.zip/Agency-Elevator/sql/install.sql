CREATE TABLE IF NOT EXISTS `agency_elevator_settings` (
    `key` VARCHAR(64) NOT NULL,
    `value` TEXT NOT NULL,
    PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `agency_elevator_settings` (`key`, `value`) VALUES
('elevator_position', 'left'),
('elevator_scale', '1.0'),
('config_position', 'center'),
('config_scale', '1.0'),
('accent_color', '#3b82f6');

CREATE TABLE IF NOT EXISTS `agency_elevators` (
    `id` VARCHAR(64) NOT NULL,
    `label` VARCHAR(128) NOT NULL,
    `floors` LONGTEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default elevators (can be edited/deleted in-game via /aelevator)
INSERT IGNORE INTO `agency_elevators` (`id`, `label`, `floors`) VALUES
('pillbox_hospital', 'Pillbox Medical Center', '[{"label":"Ground Floor","coords":{"x":338.16,"y":-583.48,"z":28.80,"w":250.0}},{"label":"1st Floor","coords":{"x":338.16,"y":-583.48,"z":32.42,"w":250.0}},{"label":"2nd Floor","coords":{"x":338.16,"y":-583.48,"z":42.42,"w":250.0}},{"label":"Roof","coords":{"x":338.16,"y":-583.48,"z":52.42,"w":250.0}}]'),
('police_station', 'Mission Row PD', '[{"label":"Entrance","coords":{"x":443.02,"y":-982.08,"z":30.69,"w":90.0}},{"label":"Basement","coords":{"x":443.02,"y":-992.08,"z":25.69,"w":90.0}},{"label":"Upper Floor","coords":{"x":443.02,"y":-982.08,"z":36.69,"w":90.0}},{"label":"Roof","coords":{"x":443.02,"y":-982.08,"z":46.69,"w":90.0}}]'),
('maze_bank_tower', 'Maze Bank Tower', '[{"label":"Lobby","coords":{"x":-75.21,"y":-818.81,"z":326.17,"w":250.0}},{"label":"Floor 10","coords":{"x":-75.21,"y":-818.81,"z":340.17,"w":250.0}},{"label":"Floor 20","coords":{"x":-75.21,"y":-818.81,"z":360.17,"w":250.0}},{"label":"Penthouse","coords":{"x":-75.21,"y":-818.81,"z":380.17,"w":250.0}}]');
