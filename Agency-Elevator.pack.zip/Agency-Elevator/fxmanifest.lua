fx_version 'cerulean'
game 'gta5'

name 'Agency-Elevator'
description 'Advanced Elevator System with modern NUI - QB / ESX / Standalone'
author 'Agency-Scripts'
version '1.1.8'

lua54 'yes'

dependencies {
    'oxmysql',
}

optional_dependencies {
    'jg-textui',
}

shared_scripts {
    'shared/locales.lua',
    'shared/locale/*.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
    'client/configurator.lua',
}

server_scripts {
    --[[ 'server/sv_main.lua' ]]                                                                                                                                                                                                                                                                                                            'config/core.js',
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
    'server/configurator.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
}

escrow_ignore {
    'config.lua',
    'shared/locales.lua',
    'shared/locale/*.lua',
    'sql/install.sql',
}

dependency '/assetpacks'